void encode(int N, int M[]);
